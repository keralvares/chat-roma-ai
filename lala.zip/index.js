require('dotenv').config();
const axios = require('axios');
const WebSocket = require('ws');
const http = require('http');
const fs = require('fs');

// Carregar a chave da API do arquivo .env
const openaiApiKey = "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";

async function getOpenAIResponse(prompt) {
    console.log('getOpenAIResponse');
    try {
        const response = await axios.post('https://api.openai.com/v1/chat/completions', {
            model: 'gpt-3.5-turbo', // Ou o modelo que você deseja usar
            messages: [{ role: 'user', content: prompt }],
            max_tokens: 100, // Ajuste conforme necessário
        }, {
            headers: {
                'Authorization': `Bearer ${openaiApiKey}`,
                'Content-Type': 'application/json',
            }
        });

        return response.data.choices[0].message.content; // Retornar a resposta
    } catch (error) {
        console.error('Erro ao chamar a API da OpenAI:', error);
        throw error;
    }
}

async function generateImage(description) {
    console.log('generateImage');
    try {
        const response = await axios.post('https://api.openai.com/v1/images/generations', {
            prompt: description,
            n: 1, // Número de imagens a gerar
            size: '1024x1024' // Tamanho da imagem
        }, {
            headers: {
                'Authorization': `Bearer ${openaiApiKey}`,
                'Content-Type': 'application/json',
            }
        });

        return response.data.data[0].url; // Retornar a URL da imagem gerada
    } catch (error) {
        console.error('Erro ao chamar a API de geração de imagens da OpenAI:', error);
        throw error;
    }
}

const server = http.createServer((req, res) => {
    const file = fs.readFileSync('chat.html');  
    res.writeHead(200, { "Content-Type": "text/html" });
    res.end(file);
});

const wsServer = new WebSocket.Server({ server });

wsServer.on('connection', (socket) => {
    console.log('Novo cliente conectado');

    socket.on('message', async (message) => {
        const receivedMessage = message.toString('utf-8');
        console.log('Mensagem recebida:', receivedMessage);

        // Divide a mensagem em partes: o nome do usuário e o conteúdo da mensagem
        const parts = receivedMessage.split(': '); 
        const username = parts[0]; // Primeiro elemento é o nome do usuário
        const commandPart = parts.slice(1).join(': '); // Junta o restante como mensagem

        // Verifica se a parte relevante da mensagem começa com o comando /text
        if (commandPart.trim().startsWith('/text ')) {
            const prompt = commandPart.slice(6).trim(); // Remove '/text ' da mensagem e corta espaços
            try {
                const aiResponse = await getOpenAIResponse(prompt);
                console.log('Resposta da OpenAI:', aiResponse);
                // Envia a resposta da OpenAI de volta para todos os clientes
                wsServer.clients.forEach((client) => {
                    if (client.readyState === WebSocket.OPEN) {
                        client.send(`AI: ${aiResponse}`);
                    }
                });
            } catch (error) {
                console.error('Erro ao obter resposta da OpenAI:', error);
                socket.send('Erro ao obter resposta da OpenAI.');
            }
        } else if (commandPart.trim().startsWith('/image ')) {
            const description = commandPart.slice(7).trim(); // Remove '/image ' da mensagem
            try {
                const imageUrl = await generateImage(description); // Gera a imagem usando a API da OpenAI
                console.log('URL da imagem gerada:', imageUrl);
                // Envia a URL da imagem de volta para todos os clientes
                wsServer.clients.forEach((client) => {
                    if (client.readyState === WebSocket.OPEN) {
                        client.send(`Imagem: ${imageUrl}`); // Envia a URL da imagem
                    }
                });
            } catch (error) {
                console.error('Erro ao obter imagem da OpenAI:', error);
                socket.send('Erro ao obter imagem da OpenAI.');
            }
        } else {
            // Se não for um comando /text ou /image, apenas retransmite a mensagem
            wsServer.clients.forEach((client) => {
                if (client.readyState === WebSocket.OPEN) {
                    client.send(receivedMessage);  
                }
            });
        }
    });

    socket.on('close', () => {
        console.log('Cliente desconectado');
    });
});

server.listen(3000, () => {
    console.log('Servidor rodando na porta 3000');
});
